# Final no-api.8 transport and source verification

The local Mac built frozen head `9c4f35fccb24ddc56f9dd9335ff772d423e5093d`, tree `27432e767ed33dbb7efd882a0057fbd7c8ce99d3`, in a fresh scratch directory. All 393 Swift test functions in 48 suites passed. They covered 513 expanded scenarios with zero skips. Testing took 34.036 seconds after compilation. All 212 tracked engineering inputs matched their pre-run hashes.

| Observed locally | Result |
| --- | --- |
| Protocol suite | 12 functions, 52 expanded scenarios and 50 actual localhost network cases with zero peer violations |
| Parallel ASR streams | Both production transports sent the same 50 × 640-byte frames and 198-byte final fragment, 32,198 bytes total |
| Delayed expert finals | The first saved WAV held 49,920 frames. Quiet and the next utterance started before both old expert finals were released. The late final updated its original record while the next utterance remained active |
| PCM continuity | Complete output waveforms matched reference conversion at 16, 22.05, 44.1 and 48 kHz |
| Playback | The position reached 0.1165 s at 0.138131208 s after play returned |
| Wizard | Normal, WebSocket-unsupported and churn cases used two GPT requests each. The reconnect case used four within its six-attempt budget |
| Text publication | The healthy engine case produced three changing revisions. Selecting unsupported text ended in the expected failed state |

Production URLSession clients exchanged PCM, WebSocket and HTTP messages with controlled local peers. They exercised incremental revisions, EOS, bounded reconnection, evidence checking and same-model fallback. Real-provider credentials, human-speech transcription accuracy, additional confirmation latency and fusion gain over the best single model remain unmeasured. The source, executable and raw assertion hashes are recorded in `run-before.json` and `run-after.json`. `native-network.log`, `driver.log`, `server.log` and `wire-audit.json` retain the exchanges.

## GitHub Actions

Both automatic workflows succeeded on the exact final PR head. Both checked out merge commit `4957fae006b621fc945189f1c8b55f68d97550c3` with the same tree as the frozen source. Its parents were the PR #5 base `4fa637a47ce869b7c7aade0ea7c0c121162e10ee` and this final head. CI passed 393 functions in 48 suites, 513 expanded cases, 50 localhost cases, 104 AppModel checks, package build, 17 probe guards, 7 setup checks, isolated startup and artifact upload. Swift Testing took 57.762 seconds. [Native run 42337118766](https://github.com/haohongfei2001-png/saytile/actions/runs/42337118766) · [Design run 42337118768](https://github.com/haohongfei2001-png/saytile/actions/runs/42337118768)

CI rendered 27 routine images and 3 approved-reference captures. It recorded 28 key-window isolation checks at each before-validation, after-validation and after-interaction phase, plus 30 at capture. CI used render-only mode, with zero AXPress. `ci-jobs.json`, `ci-snapshot.json`, `ci-merge-identity.json` and both full job logs preserve the results. No workflow was manually retriggered. The internal `b42bca49` candidate and historical no-api.7 results have separate source identities.
