# Final no-api.8 local speech

The new corpus probe linked the static SaytileKit library built from `9c4f35fccb24ddc56f9dd9335ff772d423e5093d`, tree `27432e767ed33dbb7efd882a0057fbd7c8ce99d3`. Eight newly synthesized Mandarin clips, using two voices, lasted 48.7029375 seconds. Every utterance produced local Apple Speech candidates, a completed record and a dispatchable UTF-16 revision in the isolated store.

| Measurement | Result |
| --- | --- |
| Progressive candidates per utterance | 21–31 |
| First text min / median / max | 1.179 / 1.220 / 1.265 s |
| Finalization after input min / median / max | 0.034 / 0.044 / 0.090 s |
| Normalized CER per utterance | 0–26.32% |
| Missing expected phrases | “Mac”, “保存原音”, “充电器”, “修改开始时间” |

The CER code folds case and width and removes punctuation and whitespace. `apple-corpus.json` includes individual expected strings, actual transcripts, event times and errors. The corpus measures this synthetic local workload. Human-speech accuracy and comparative cloud-fusion gains remain unmeasured.

The current executable's first Chinese-asset inventory reported supported and uninstalled with zero reservations out of five. One bounded official product preparation call returned with Chinese installed and reserved. The probe released no other locale and opened no microphone or cloud-provider account. The asset observer did not measure downloaded bytes. `asset-preparation.json`, `fixture-identity.json`, `probe-source-identity.json`, `receipt.json` and `apple-summary.json` preserve raw inventory, input, source and binary identities. `signed-app.json` records the independent extracted-package check.
