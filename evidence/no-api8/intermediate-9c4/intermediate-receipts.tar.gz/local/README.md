# no-api.8 local verification

Frozen runtime `9c4f35fccb24ddc56f9dd9335ff772d423e5093d`, tree `27432e767ed33dbb7efd882a0057fbd7c8ce99d3`, passed all eight short checks. Its single 30-minute capture started at 12:15:34 China Standard Time on 2026-11-07 under PID 57437. The release-boundary change intentionally stopped this partial run after 794.04 seconds. They use the committed synthetic Tingting input bound by `input-fixture.json` and dedicated `/tmp/saytile-no-api8-<revision-prefix>` scratch paths. Resource samples observe the owned capture process and its disposable SQLite database at 45-second intervals.

Store passed all 12 process recovery, migration and rollback checks. The synthetic archive contained 100,000 recordings and 300,000 revisions. Partial writes took 0.326 ms p95, and the expected 100 search matches took 176.981 ms. VAD processed 66.7 MB with a peak RSS increase of 245,760 bytes. The independent AVAudioConverter received all 4,845 batches and produced 28,800,000 frames with PCM SHA-256 `050b5e8b2a4154d34590f79cfb949885cc5195271bc7dd72ff8f4aab27885385`.

The short checks and capture used the following frozen identifiers.

```sh
export SAYTILE_FROZEN_SHA=9c4f35fccb24ddc56f9dd9335ff772d423e5093d
export SAYTILE_FROZEN_TREE=27432e767ed33dbb7efd882a0057fbd7c8ce99d3
python3 evidence/no-api8/local/run-short-evidence.py > evidence/no-api8/local/short-driver.log 2>&1
python3 evidence/no-api8/local/run-realtime-evidence.py > evidence/no-api8/local/realtime-monitor.log 2>&1
python3 evidence/no-api8/local/finalize-realtime-evidence.py > evidence/no-api8/local/realtime-assessment.log 2>&1
```

## Superseded partial capture

The release boundary moved to `69b90939fd688b35448f976950e96db0ce5b602a`. Root requested TERM for only the verified capture PID 57437 recorded in `INTENTIONALLY_STOPPED_FOR_RELEASE_BOUNDARY.json`. It ran for 794.04 seconds. The source remained unchanged and the original runner receipt records exit 143 / FAIL. The final assessment was not run. The 18 resource observations are retained, including 26 recordings, 77 chunks and 12,280,000 frames in the last persistence snapshot. The new release verification uses its own database, executables, worktree and receipt directory.
