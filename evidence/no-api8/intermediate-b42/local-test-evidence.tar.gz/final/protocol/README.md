# Superseded internal no-api.8 source and transport verification

These receipts identify internal candidate `b42bca49`. The final no-api.8 source is `9c4f35fc`, which includes later production UI, window geometry and test changes. This internal candidate was not the published no-api.8 DMG.

The frozen head `b42bca49cf472205c605f9a50342ea43a4220275` has tree `6e1a71194fdba419b6d9ddb35d12f5c85a2ed1b7`. A fresh Swift build on the local Mac passed 392 test functions in 48 suites, comprising 512 expanded cases. Testing took 33.812 seconds after compilation. All 212 tracked engineering inputs matched their before/after hashes. The suite recorded zero skips.

| Observed locally | Result |
| --- | --- |
| Provider transport | 12 functions and 52 expanded scenarios, including 50 actual localhost network cases with zero peer violations |
| Simultaneous ASR inputs | Both clients received the same 50 × 640-byte frames and a 198-byte final fragment, 32,198 bytes total |
| VAD and delayed expert finalization | The first WAV contained 49,920 frames. Both expert finals were held across quiet and the next utterance onset. A late final updated only its original record while the next utterance remained active |
| Audio continuity | Complete waveforms matched at 16, 22.05, 44.1 and 48 kHz |
| Playback | Position advanced to 0.1505 s at 0.172058958 s after play returned |
| Connection wizard | Normal, WS-unsupported and churn checks each used two GPT requests. Reconnect used four, within the shared six-attempt budget |
| Unified output | The healthy engine case published three changing revisions and completed. The unsupported-selection case ended in the expected failed state |

The current production transports sent WebSocket and HTTP messages, streamed real PCM to the local peers and processed partial and terminal responses. The peers supplied controlled transcripts and faults. Cloud account connectivity, real-provider transcription accuracy, confirmation latency and gains over a single model remain unmeasured. `run-before.json`, `run-after.json`, `driver.log`, `native-network.log`, `server.log` and `wire-audit.json` preserve the command, binary hashes and network records. The artifacts from prior UI revisions remain separate.

Design CI succeeded. Native CI passed the full 392 functions and 50 network cases, AppModel 104, both CLI boundaries, package build, isolated startup and the render-only UI run. It rendered 27 routine images and four reference images. GitHub cancelled the final artifact upload, so the workflow conclusion is cancelled. Both jobs checked out merge `4befc193d763a8165a8098a8552c69500ec89792` with the internal candidate's tree. The full logs and checkout receipt are preserved next to this report. [Internal native run 42336604503](https://github.com/haohongfei2001-png/saytile/actions/runs/42336604503) · [Internal design run 42336604559](https://github.com/haohongfei2001-png/saytile/actions/runs/42336604559)
