# no-api.8 on-device Apple Speech

The probe linked the static SaytileKit library built from `b42bca49cf472205c605f9a50342ea43a4220275`, tree `6e1a71194fdba419b6d9ddb35d12f5c85a2ed1b7`. It generated eight new Mandarin AIFF files in an isolated directory, totaling 48.7029375 seconds across two synthetic voices. Apple Speech produced progressive candidates, locally recorded evidence and a dispatchable revision for all eight utterances.

| Measurement | Result |
| --- | --- |
| Progressive candidates per utterance | 21–31 |
| First text min / median / max | 1.138 / 1.161 / 1.184 s |
| Finalization after input min / median / max | 0.031 / 0.040 / 0.083 s |
| Per-utterance normalized CER range | 0–26.32% |
| Expected phrases absent from transcripts | “Mac”, “保存原音”, “充电器”, “修改开始时间” |

The CER calculation folds width and case and removes whitespace and punctuation. `apple-corpus.json` retains each input reference, actual transcript, expected phrases and timings. Results apply to this synthetic corpus. Human-speech accuracy and comparative gains from cloud fusion remain unmeasured.

The initial inventory of the current executable reported Chinese supported and uninstalled with zero reserved locales out of five. One bounded official `AppleSpeechService.prepare()` call returned with Chinese installed and reserved. The two inventory observations were 0.055 seconds apart. No locale was released. The measurement does not establish a download size. There was no live microphone or cloud-provider call.

`fixture-identity.json`, `receipt.json`, `probe-source-identity.json`, `asset-preparation.json` and `apple-summary.json` record the sources, inputs, executable, inventory and aggregate measurements. The optional preparation observer was the only change to the corpus probe. The separate signed package check is recorded in `signed-app.json`.
