# no-api.8 AppModel and browser input

The AppModel probe passed 104 checks against the fresh SaytileKit build of `b42bca49cf472205c605f9a50342ea43a4220275`, tree `6e1a71194fdba419b6d9ddb35d12f5c85a2ed1b7`. It used an isolated store and injected capture and connection actions. `app-model-identity.json` records the source, executable, static library and result hashes.

The production Swift input coordinator, SQLite reservation logic and UTF-16 range handling passed 20 checks on a loopback page. These covered suffix-only insertion, duplicate suppression, selection, navigation, focus changes and zero sends for textarea and contenteditable targets. Chromium used a fresh headless context. DOM target discovery and editing came from the test adapter. Native Accessibility input has its own receipts.

`browser-identity.json`, `dom-binary-identity.json` and `input-browser-dom.log` preserve the browser, probe and assertions. An observer preflight initially used the wrong Swift fixture filename and stopped before launching Chromium. After the path correction, the product browser test ran once.
