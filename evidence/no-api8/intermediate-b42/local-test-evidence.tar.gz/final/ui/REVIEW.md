# Packaged input panel and original-reference review

Both modes launched the App extracted from the read-only no-api.8 DMG. Runtime `b42bca49cf472205c605f9a50342ea43a4220275`, tree `6e1a71194fdba419b6d9ddb35d12f5c85a2ed1b7`. The executable SHA-256 is `a96446f5debf1ee8b423877d796e13cadf89a47a2b88cd604e6919e528872cf1`. The DMG SHA-256 is `4592d3955f5439f706c1971dbb470a4810ccb833f63bfbda56458294deac816b`. Both matched the package receipt. [Package](../package-identity.json) · [Image and executable hashes](execution-receipt.json)

## Original-reference measurements

Rule 21 identifies the supplied 1536 × 1024 JPEG by SHA-256 `58be88a019cf0241b1c540f799d0944ed294e650b8c119923a434a6e4889a7c5`. This review used the project's recorded measurements and newly rendered package images. No copy of the original attachment, earlier PNG or personal desktop was accessed or republished. The earlier .6 and .7 panel screenshots remain historical engineering evidence. [Reference authority and scope](../reference-source.json) · [Recorded design dimensions](../../../../docs/V1-ORIGINAL-REFERENCE-FIDELITY.md)

| Feature | Observed in the shipping App |
|---|---|
| Panel and type | Three reference states were independently captured at 345 × 234 pt, 690 × 468 pixels. The complete same-sentence fixture and 19.5 pt native font were checked in all three. The sentence wraps naturally into five lines. The first line's dark ink begins at x = 46 px (23 pt), with roughly 52 px (26 pt) between rows. The specified corner radius is 28 pt in source. No radius was inferred from a JPEG edge. |
| Controls | All eleven live AX panel inspections measured 42 × 34 pt for copy and 92 × 34 pt for the only voice button. Both bottom gaps measured 18 pt. Two overlapping rounded gray squares are visible at left. The most frequent gray core RGBA is (111,112,132,255). |
| Speech states and marker | The package renders a right-facing triangle when paused, one round dot in standby and five rounded vertical bars while speaking. The speaking reference has a 5 × 38 px purple end marker. Neither paused nor standby contains a purple marker in the text region. The ordinary VAD case returns to the dot while the latest text remains readable. |
| Surface | Reference panel pixels at x = 90, 345 and 600 and y = 320 have RGB values (217,211,251), (206,208,252) and (189,198,251), decoded from the image file. Interior samples have alpha 255. The outside top corner has alpha zero. Both run modes produced byte-identical corresponding files for all four reference images. |

[Paused](original-reference/reference-paused.png) · [Standby](original-reference/reference-standby.png) · [Speaking](original-reference/reference-speaking.png) · [AX and pixel measurements](reference-measurements.json) · [Measurement script](measure-reference.py)

The fourth image uses a synthetic surrounding gradient and sample shadow, with the actual production panel in a 425 × 314 pt review host. The three standalone states establish the panel's rendering without that staging. The measured results establish selected geometric and visual properties, while direct original-pixel equivalence, desktop transmission and user visual acceptance were not measured. [Staged presentation](original-reference/reference-presentation.png)

## Interaction and scope

The controls run captured 37 ordinary images and four reference images. It executed 45 AXPress actions, ten context-menu selections, six field edits including three secure fields, and eleven two-control inspections across 15 functional groups. Selection and full-transcript copy used a private pasteboard. The near-bottom/read anchor held through update. First-connection results were TEST_ONLY injected receipts. The separate render-only run captured 27 ordinary images and four reference images with zero AX actions. Both runs reported zero foreground changes. Each run also rendered 71 neutral geometry samples in a diagnostic 78 × 30 pt canvas. The full native panel and AX measurements establish the actual capsule size and colors. [Controls manifest](manifest.json) · [Render-only manifest](../ui-render-only/manifest.json) · [Raw actions](run.log) · [Neutral geometry](voice-glyph-audit.json)

Speech level, recognition state and service responses in these UI scenarios were synthetic. They demonstrate state presentation and the VAD/late-result behavior of the product controller. The source turns off state and level animations when Reduce Motion is enabled. No change of OS settings, timed display-frame measurements, physical microphone input, real cloud call or foreground-user draft was involved. [VAD ended](panel-capture-vad-ended.png) · [Narrow panel](panel-compact.png) · [Input findings](../input/NATIVE-INPUT.md)
