# no-api.8 local verification

Frozen runtime `b42bca49cf472205c605f9a50342ea43a4220275`, tree `6e1a71194fdba419b6d9ddb35d12f5c85a2ed1b7`, passed all eight short checks. Its 30-minute capture started at 12:03:58 China Standard Time on 2026-11-07 under PID 47229. Root stopped this unpublished capture after 484.98 seconds because a newer implementation superseded it. They use the committed synthetic Tingting input bound by `input-fixture.json` and dedicated `/tmp/saytile-no-api8-<revision-prefix>` scratch paths. Resource samples observe the owned capture process and its disposable SQLite database at 45-second intervals.

Store passed the 12 recovery, migration and rollback checks. The synthetic archive contained 100,000 recordings and 300,000 revisions. Its partial writes took 0.124 ms p95, and the expected 100 search matches took 159.156 ms. VAD processed 66.7 MB with a peak RSS increase of 262,144 bytes. The independent reference received all 4,845 batches and produced 28,800,000 frames with PCM SHA-256 `050b5e8b2a4154d34590f79cfb949885cc5195271bc7dd72ff8f4aab27885385`.

The short checks and capture used the following frozen identifiers.

```sh
export SAYTILE_FROZEN_SHA=b42bca49cf472205c605f9a50342ea43a4220275
export SAYTILE_FROZEN_TREE=6e1a71194fdba419b6d9ddb35d12f5c85a2ed1b7
python3 evidence/no-api8/local/run-short-evidence.py > evidence/no-api8/local/short-driver.log 2>&1
python3 evidence/no-api8/local/run-realtime-evidence.py > evidence/no-api8/local/realtime-monitor.log 2>&1
python3 evidence/no-api8/local/finalize-realtime-evidence.py > evidence/no-api8/local/realtime-assessment.log 2>&1
```

## Superseded capture

Only the identified capture process (PID 47229, binary SHA-256 `24bf1bba7d81b8d292ffd11b3fa65a9b05f25f01271d2155c515779a0e0ac7d5`) received SIGTERM. The runner retained its original exit 143 and FAIL receipt, with unchanged runtime source. The final waveform assessor was not run. The 484.98-second partial observation is retained for diagnosis and has no 30-minute pass status. See `INTENTIONALLY_STOPPED_FOR_SUPERSEDING_VISUAL_FIX.json`, `source-after.json`, `realtime-run.log`, and the original resource/persistence streams. The replacement runtime is `9c4f35fccb24ddc56f9dd9335ff772d423e5093d` and uses a separate worktree, scratch space and database.
