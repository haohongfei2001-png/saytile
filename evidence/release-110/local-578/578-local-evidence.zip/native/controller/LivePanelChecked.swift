import AppKit
import ApplicationServices
import CoreAudio

struct ObservationError: LocalizedError {
    let reason: String
    var errorDescription: String? { reason }
    init(_ reason: String) { self.reason = reason }
}

func attribute(_ element: AXUIElement, _ key: String) -> CFTypeRef? {
    var value: CFTypeRef?
    return AXUIElementCopyAttributeValue(element, key as CFString, &value) == .success ? value : nil
}

func elementAttribute(_ element: AXUIElement, _ key: String) -> AXUIElement? {
    guard let value = attribute(element, key), CFGetTypeID(value) == AXUIElementGetTypeID() else { return nil }
    return unsafeBitCast(value, to: AXUIElement.self)
}

func search(_ roots: [AXUIElement], owner: pid_t, match: (AXUIElement) -> Bool) -> AXUIElement? {
    var queue = roots
    var seen = Set<CFHashCode>()
    while !queue.isEmpty, seen.count < 240 {
        let node = queue.removeFirst()
        var pid: pid_t = 0
        guard AXUIElementGetPid(node, &pid) == .success, pid == owner,
              seen.insert(CFHash(node)).inserted else { continue }
        if match(node) { return node }
        if let list = attribute(node, kAXChildrenAttribute) as? [AXUIElement] { queue += list }
    }
    return nil
}

func runningInput(_ pid: pid_t) -> Bool? {
    var process = pid
    var object = AudioObjectID(0)
    var size = UInt32(MemoryLayout.size(ofValue: object))
    var address = AudioObjectPropertyAddress(mSelector: kAudioHardwarePropertyTranslatePIDToProcessObject,
                                             mScope: kAudioObjectPropertyScopeGlobal, mElement: kAudioObjectPropertyElementMain)
    guard AudioObjectGetPropertyData(AudioObjectID(kAudioObjectSystemObject), &address,
              UInt32(MemoryLayout.size(ofValue: process)), &process, &size, &object) == noErr else { return nil }
    if object == kAudioObjectUnknown { return false }
    var flag: UInt32 = 0
    address.mSelector = kAudioProcessPropertyIsRunningInput
    guard AudioObjectGetPropertyData(object, &address, 0, nil, &size, &flag) == noErr else { return nil }
    return flag != 0
}

func waitFor<T>(_ seconds: Double = 6, _ reason: String, _ check: () -> T?) throws -> T {
    let end = ProcessInfo.processInfo.systemUptime + seconds
    repeat {
        if let value = check() { return value }
        Thread.sleep(forTimeInterval: 0.12)
    } while ProcessInfo.processInfo.systemUptime < end
    throw ObservationError(reason)
}

func press(_ node: AXUIElement, _ label: String) throws {
    AXUIElementSetMessagingTimeout(node, 0.65)
    let status = AXUIElementPerformAction(node, kAXPressAction as CFString)
    // Synchronous menu tracking sometimes outlives an AX reply. Observe its
    // postcondition exactly once instead of replaying an ambiguous action.
    guard status == .success || status == .cannotComplete else {
        throw ObservationError("\(label) AX result \(status.rawValue)")
    }
}

@main struct LivePanel {
    static func run() throws {
        guard CommandLine.arguments.count == 4, let pid = pid_t(CommandLine.arguments[1]),
              ["cycle", "speech", "route", "acoustic", "close"].contains(CommandLine.arguments[3]),
              AXIsProcessTrusted() else { throw ObservationError("target arguments or existing AX permission unavailable") }
        let session = URL(fileURLWithPath: CommandLine.arguments[2]).resolvingSymlinksInPath()
        let appPath = "/private/tmp/saytile-release-110-pro-7eb459f1/.build/pro-110/distribution/stage/Saytile.app"
        let permittedRoot = URL(fileURLWithPath: "/private/tmp", isDirectory: true).resolvingSymlinksInPath()
        guard session.lastPathComponent.hasPrefix("saytile-578-live-"),
              session.deletingLastPathComponent().standardizedFileURL.path == permittedRoot.standardizedFileURL.path
        else { throw ObservationError("session is outside the owned fixture root") }
        var path = [CChar](repeating: 0, count: 4096)
        let expectedExecutable = URL(fileURLWithPath: appPath + "/Contents/MacOS/Saytile").resolvingSymlinksInPath()
        guard proc_pidpath(pid, &path, UInt32(path.count)) > 0,
              URL(fileURLWithPath: String(cString: path)).resolvingSymlinksInPath().path == expectedExecutable.path
        else { throw ObservationError("candidate executable identity mismatch") }
        let info = Process()
        info.executableURL = URL(fileURLWithPath: "/bin/ps")
        info.arguments = ["-p", String(pid), "-ww", "-o", "command="]
        let pipe = Pipe()
        info.standardOutput = pipe
        try info.run()
        info.waitUntilExit()
        let command = String(decoding: pipe.fileHandleForReading.readDataToEndOfFile(), as: UTF8.self)
        guard command.trimmingCharacters(in: .whitespacesAndNewlines) ==
                appPath + "/Contents/MacOS/Saytile --data-directory " + CommandLine.arguments[2] + "/data" else {
            throw ObservationError("target is not the explicitly isolated candidate")
        }
        if CommandLine.arguments[3] == "close" {
            guard let app = NSRunningApplication(processIdentifier: pid), app.terminate()
            else { throw ObservationError("owned candidate did not accept quit") }
            return
        }
        let root = AXUIElementCreateApplication(pid)
        func panels() -> [AXUIElement] {
            (attribute(root, kAXWindowsAttribute) as? [AXUIElement] ?? []).filter {
                (attribute($0, kAXTitleAttribute) as? String) == "Saytile · 此刻"
            }
        }
        let item = try waitFor(8, "owned Saytile status item unavailable") {
            guard let extra = elementAttribute(root, kAXExtrasMenuBarAttribute) else { return nil as AXUIElement? }
            return search([extra], owner: pid) { node in
                guard attribute(node, kAXRoleAttribute) as? String == kAXMenuBarItemRole else { return false }
                return [kAXTitleAttribute, kAXHelpAttribute, kAXDescriptionAttribute].contains {
                    (attribute(node, $0) as? String)?.contains("Saytile 菜单") == true
                }
            }
        }
        let purpose = CommandLine.arguments[3]
        if ["route","speech","acoustic"].contains(purpose) {
            guard runningInput(pid) == false else { throw ObservationError("expected microphone off before choosing model") }
            try press(item, "open owned menu")
            let openSettings = try waitFor(5, "owned settings item missing") {
                search([item], owner: pid) { attribute($0, kAXTitleAttribute) as? String == "语音档案与设置…" }
            }
            try press(openSettings, "open owned workspace")
            func settings(_ id: String) -> AXUIElement? {
                let windows = (attribute(root, kAXWindowsAttribute) as? [AXUIElement] ?? []).filter {
                    attribute($0, kAXTitleAttribute) as? String == "语音档案与设置"
                }
                return search(windows, owner: pid) { attribute($0,kAXIdentifierAttribute) as? String == id }
            }
            let page = try waitFor(7, "native local model settings missing") { settings("settings.page.models") }
            try press(page,"open native local model settings")
            func label(_ el: AXUIElement) -> String {
                [kAXTitleAttribute,kAXDescriptionAttribute,kAXValueAttribute].compactMap { attribute(el,$0) as? String }.joined(separator:" ")
            }
            let modelID = "models.use.qwen-small"
            let choose = try waitFor(18, "verified installed Qwen control missing") {
                guard let control = settings(modelID) else { return nil as AXUIElement? }
                return (attribute(control,kAXEnabledAttribute) as? Bool == true || label(control).contains("默认使用") || label(control).contains("已选择")) ? control : nil
            }
            if attribute(choose,kAXEnabledAttribute) as? Bool == true { try press(choose,"select installed Qwen") }
            _ = try waitFor(8, "native local settings did not confirm Qwen selection") {
                guard let choice = settings(modelID), attribute(choice,kAXEnabledAttribute) as? Bool == false else { return nil as Bool? }
                let value=label(choice)
                return (value.contains("已选择") || value.contains("默认使用")) ? true : nil
            }
            guard runningInput(pid) == false else { throw ObservationError("reading settings unexpectedly engaged microphone") }
            print("QWEN_SETTINGS_VERIFIED microphone_off=true")
            if purpose == "route" { return }
        }
        if panels().isEmpty {
            try press(item, "show status menu")
            let open = try waitFor(4, "isolated status menu lacks 展开语音板") {
                search([item], owner: pid) { (attribute($0, kAXTitleAttribute) as? String) == "展开语音板" }
            }
            try press(open, "show isolated panel")
        }
        func capture() -> AXUIElement? {
            search(panels(), owner: pid) { attribute($0, kAXIdentifierAttribute) as? String == "panel.capture" }
        }
        let control = try waitFor(5, "owned native panel capture control unavailable", capture)
        guard runningInput(pid) == false else { throw ObservationError("candidate did not begin with idle hardware") }
        let start = ProcessInfo.processInfo.systemUptime
        func evidence(_ event: String) {
            let t = ProcessInfo.processInfo.systemUptime - start
            print("HARDWARE \(event) elapsed=\(String(format: "%.3f", t)) pid=\(pid) own_input=\(String(describing: runningInput(pid)))")
            fflush(stdout)
        }
        evidence("initial")
        let live = CommandLine.arguments[3] == "speech"
        func observeLength(for duration: Double, phase: String, whilePlaying playback: Process? = nil) {
            let until = ProcessInfo.processInfo.systemUptime + duration
            var previous: Int?
            while ProcessInfo.processInfo.systemUptime < until && (playback?.isRunning ?? true) {
                if let editor = search(panels(), owner: pid, match: {
                    (attribute($0, kAXIdentifierAttribute) as? String) == "panel.transcript"
                }), let length = attribute(editor, kAXNumberOfCharactersAttribute) as? NSNumber,
                   length.intValue != previous {
                    previous = length.intValue
                    print("PANEL_LENGTH phase=\(phase) elapsed=\(String(format: "%.3f", ProcessInfo.processInfo.systemUptime-start)) utf16=\(length.intValue)")
                    fflush(stdout)
                }
                Thread.sleep(forTimeInterval: 0.3)
            }
        }
        for n in 1...((live || purpose == "acoustic") ? 1 : 2) {
            try press(n == 1 ? control : try waitFor(3, "resume control unavailable", capture), "start or resume capture")
            _ = try waitFor(12, "hardware did not start") { runningInput(pid) == true ? true : nil }
            evidence(n == 1 ? "started" : "resumed")
            if live {
                print("现在可以自然讲话，中间短停后继续。一分钟后会提示长停顿。")
                fflush(stdout)
                observeLength(for: 60, phase: "first")
                print("现在请停顿约 32 秒，然后再继续。")
                fflush(stdout)
                observeLength(for: 32, phase: "silence")
                print("可以继续讲话。约一分钟后自动结束。")
                fflush(stdout)
                observeLength(for: 60, phase: "second")
            } else if purpose == "acoustic" {
                let player=Process()
                player.executableURL=URL(fileURLWithPath:"/usr/bin/afplay")
                player.arguments=["/private/tmp/saytile-release-110-pro-7eb459f1/.build/pro-110/asr-validation/public-fixtures/fleurs-zh-13737992583400421680.wav"]
                Thread.sleep(forTimeInterval:0.4)
                try player.run()
                defer { if player.isRunning { player.terminate() } }
                evidence("playbackStarted")
                observeLength(for:16,phase:"publicPlayback",whilePlaying:player)
                guard !player.isRunning, player.terminationStatus == 0 else { throw ObservationError("public clip playback incomplete") }
                evidence("playbackEnded")
                observeLength(for:4,phase:"afterPublicPlayback")
            } else {
                Thread.sleep(forTimeInterval: 0.35)
            }
            try press(try waitFor(3, "pause control unavailable", capture), "pause capture")
            _ = try waitFor(7, "hardware did not stop") { runningInput(pid) == false ? true : nil }
            Thread.sleep(forTimeInterval: 0.45)
            guard runningInput(pid) == false else { throw ObservationError("hardware restarted after pause") }
            evidence("paused")
        }
        print("CONTROL_CYCLE_PASS")
    }
    static func main() {
        do { try run() }
        catch { print("CONTROL_BLOCKED \(error.localizedDescription)"); exit(1) }
    }
}
