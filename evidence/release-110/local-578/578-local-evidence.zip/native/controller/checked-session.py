"""Operate one owned 578 instance. Persist only metadata, never recorded audio or copy contents in the acceptance report."""
import datetime
import ctypes
import hashlib
import json
import os
from pathlib import Path
import shutil
import sqlite3
import signal
import subprocess
import sys
import tempfile
import time

mode = sys.argv[1]
assert mode in {"cycle", "speech", "route", "acoustic"}
base = Path(__file__).resolve().parent
root = Path("/private/tmp/saytile-release-110-pro-7eb459f1")
binary = root / ".build/pro-110/distribution/stage/Saytile.app/Contents/MacOS/Saytile"
assert hashlib.sha256(binary.read_bytes()).hexdigest() == "7cd25d7fa5672775502adcbe2c12476abec97a3ecd195fa176f66a69e58c4e98"
temporary = Path(tempfile.mkdtemp(prefix="saytile-578-live-", dir="/private/tmp"))
data = temporary / "data"
(data / "LocalModels").mkdir(parents=True)
timestamp = datetime.datetime.now().strftime("%Y%m%d-%H%M%S")
receipt = base / f"{mode}-{timestamp}.json"
result = {"mode": mode, "source": "7eb459f1a07473ef3a2b66e6bba6b26cbc4f28ef", "build": 578,
          "started": datetime.datetime.now().astimezone().isoformat(), "status": "BLOCKED"}
owned = None
target_pid = None
app = binary.parents[2]
libproc = ctypes.CDLL("/usr/lib/libproc.dylib")
def find_target():
    pids = subprocess.run(["pgrep", "-x", "Saytile"], text=True, capture_output=True).stdout.split()
    for raw_pid in pids:
        candidate = int(raw_pid)
        image = ctypes.create_string_buffer(4096)
        if libproc.proc_pidpath(candidate, image, len(image)) <= 0 or Path(os.fsdecode(image.value)).resolve() != binary:
            continue
        args = subprocess.run(["ps", "-ww", "-p", str(candidate), "-o", "command="],
                              capture_output=True, text=True).stdout.strip()
        if args == f"{binary} --data-directory {data}":
            return candidate
    return None
try:
    if mode == "acoustic":
        source = root/".build/pro-110/asr-validation/public-fixtures/fleurs-zh-13737992583400421680.wav"
        result["fixture_sha256"] = hashlib.sha256(source.read_bytes()).hexdigest()
        assert result["fixture_sha256"]=="2c130c47ae74549ca6b33e06a547e2165e14f665380d29cefe6667fa5602fe47"
        devices=json.loads(subprocess.check_output(["system_profiler","SPAudioDataType","-json"]))["SPAudioDataType"][0]["_items"]
        for direction in ("input","output"):
            current=[dev for dev in devices if dev.get("coreaudio_default_audio_"+direction+"_device")=="spaudio_yes"]
            assert len(current)==1 and current[0].get("coreaudio_device_transport")=="coreaudio_device_type_builtin"
        result["default_input_and_output_builtin"]=True
    subprocess.run(["cp", "-cR", "/private/tmp/saytile-023-weights/qwen-small", data/"LocalModels"], check=True)
    log_path = temporary/"app.log"
    with log_path.open("wb") as app_log:
        owned = subprocess.Popen(["/usr/bin/open", "-n", "-g", "-W", "-o", log_path, "--stderr", temporary/"app.stderr",
                                 app, "--args", "--data-directory", data], stdout=subprocess.DEVNULL, stderr=app_log)
        deadline = time.monotonic()+14
        while "SAYTILE_ISOLATED_LAUNCH cloud_enabled=false" not in log_path.read_text(errors="replace"):
            if owned.poll() is not None or time.monotonic() >= deadline:
                raise RuntimeError("candidate did not confirm an isolated offline launch")
            time.sleep(.12)
        target_pid = find_target()
        if target_pid is None:
            raise RuntimeError("LaunchServices instance with exact binary and isolated arguments was not found")
        with (base / f"{mode}-{timestamp}.log").open("x") as control_log:
            child = subprocess.Popen([base/"live-panel-checked", str(target_pid), temporary, mode],
                                     stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
            for line in child.stdout:
                print(line, end="", flush=True)
                control_log.write(line)
                if mode == "speech" and line.startswith(("现在可以自然讲话", "现在请停顿", "可以继续讲话")):
                    subprocess.Popen(["/usr/bin/osascript","-e",
                        'on run argv\ndisplay notification (item 1 of argv) with title "Saytile 现场验收"\nend run',line.strip()],
                        stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
            if child.wait() != 0:
                raise RuntimeError("owned controller did not observe all requested transitions")
        if mode == "route":
            result["route"] = "qwen-small"
            result["microphone"] = "off throughout the model selection"
        else: result["hardware_cycle"] = "PASS"
        result["status"] = "PASS" if mode in {"cycle","route"} else "NEEDS_LIVE_RECORD_VALIDATION"
except Exception as error:
    result["error"] = str(error)
finally:
    if owned is not None and owned.poll() is None:
        close = None
        target_pid = target_pid or find_target()
        if target_pid is not None:
            close = subprocess.run([base/"live-panel-checked", str(target_pid), temporary, "close"],
                                   capture_output=True, timeout=5)
        try:
            owned.wait(timeout=12)
        except subprocess.TimeoutExpired:
            if target_pid is not None and target_pid == find_target():
                os.kill(target_pid, signal.SIGTERM)
            else:
                owned.terminate()
            owned.wait(timeout=5)
            result["forced_test_process_exit"] = True
            result["status"] = "BLOCKED"
        result["normal_quit_request"] = close is not None and close.returncode == 0
    if (data/"Saytile.sqlite").exists():
        with sqlite3.connect((data/"Saytile.sqlite").as_uri()+"?mode=ro", uri=True) as db:
            result["integrity"] = db.execute("pragma integrity_check").fetchone()[0]
            result["record_summary"] = db.execute("select recognition_state, audio_state, total_frames, is_recording from recordings order by created_at").fetchall()
            result["paragraph_count"] = db.execute("select count(distinct paragraph_start) from timeline_paragraphs").fetchone()[0]
            result["external_dispatches"] = db.execute("select count(*) from dispatches").fetchone()[0]
            if mode == "speech":
                result["providers"] = [row[0] for row in db.execute("select distinct json_extract(payload,'$.provider') from model_runs")]
                rows = db.execute("""select t.started,t.ended,p.paragraph_start,length(v.text)
                    from transcript_timeline t join timeline_paragraphs p on p.position=t.position
                    join recordings r on r.id=t.recording_id left join revisions v on v.id=r.preferred_revision
                    order by t.position""").fetchall()
                result["recognized_lengths"] = [r[3] for r in rows]
                result["end_to_start_intervals"] = [
                    {"seconds":round(curr[0]-prev[1],3),"same_paragraph":curr[2]==prev[2]}
                    for prev,curr in zip(rows,rows[1:]) if prev[1] is not None]
            if mode == "acoustic":
                result["route"]=[r[0] for r in db.execute("select distinct json_extract(payload,'$.provider') from model_runs")]
                texts=[row[0] for row in db.execute("""select coalesce(v.text,'') from transcript_timeline t
                    join recordings r on r.id=t.recording_id left join revisions v on v.id=r.preferred_revision order by t.position""")]
                observed="".join(texts)
                same_clip=json.loads((base/"paced-paragraphs/visible-public.json").read_text())["archive"][0]
                def distance(a,b):
                    previous=list(range(len(b)+1))
                    for i,first in enumerate(a,1):
                        current=[i]
                        for j,second in enumerate(b,1):
                            current.append(min(previous[j]+1,current[-1]+1,previous[j-1]+(first!=second)))
                        previous=current
                    return previous[-1]
                result["file_route_chars"]=len(same_clip)
                result["acoustic_chars"]=len(observed)
                result["edit_distance_to_same_file_route"]=distance(same_clip,observed)
                import re
                trace=(base/f"{mode}-{timestamp}.log").read_text()
                started=re.search(r"HARDWARE playbackStarted elapsed=([.0-9]+)",trace)
                ended=re.search(r"HARDWARE playbackEnded elapsed=([.0-9]+)",trace)
                changes=[(float(t),int(n)) for t,n in re.findall(r"PANEL_LENGTH phase=publicPlayback elapsed=([.0-9]+) utf16=([0-9]+)",trace) if int(n)>0]
                result["native_changed_lengths_during_playback"]=len(changes)
                if started and ended:
                    result["playback_seconds"]=round(float(ended[1])-float(started[1]),3)
                    result["first_native_nonempty_after_playback_start_s"]=round(changes[0][0]-float(started[1]),3) if changes else None
                result["status"]="PASS" if (started and ended and len(changes)>=2 and observed and
                    result["route"]==["qwen-small"] and result["integrity"]=="ok" and result["normal_quit_request"] and
                    result["external_dispatches"]==0 and all(row[0:2]==("completed","available") for row in result["record_summary"])) else "FAIL"
    if mode in {"cycle","route","acoustic"}:
        shutil.rmtree(temporary)
    else:
        result["private_local_session"] = str(data)
        print("本次现场语音仅存于独立本机目录。")
    receipt.write_text(json.dumps(result, indent=2)+"\n")
    print(receipt)
if result["status"] == "BLOCKED":
    sys.exit(1)
